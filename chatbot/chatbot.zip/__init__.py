import os
from flask import Flask, jsonify, request
import mysql.connector
from heyoo import WhatsApp
import requests
from dotenv import load_dotenv
from common.utils.component_service import component_service
# Carga las variables de entorno desde el archivo .env
load_dotenv()

app = Flask(__name__)

component_service(app)

# Configuración desde variables de entorno
BASE_API_URL = os.getenv("BASE_API_URL")
CREUS_BASE_URL = os.getenv("CREUS_BASE_URL")
token = os.getenv("WA_TOKEN")
idNumeroTelefono = os.getenv("WA_PHONE_ID")
token_verificacion = os.getenv("VERIFY_TOKEN")

# Inicializa el objeto de WhatsApp
mensajeWa = WhatsApp(token, idNumeroTelefono)

MENU = (
    "1️⃣ *Horario de atención* 🕙\n"
    "2️⃣ *Carreras activas* 🎓\n"
    "3️⃣ *Información de contacto* 📇\n"
    "4️⃣ *Últimas noticias* 📰\n"
    "5️⃣ *Preguntas frecuentes* ❓\n\n"
    "Por favor, respondé con el número de la opción que te interese.\n"
)


def get_db_connection():
    """
    Retorna una conexión activa a la base de datos MySQL.
    """
    return mysql.connector.connect(
        host=os.getenv("DB_HOST"),
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASSWORD"),
        database=os.getenv('DB_NAME')
    )

def limpiar_registros_usuarios(umbral=50, dejar=5):
    """
    Por cada usuario (telefono_wa), si tiene más de 'umbral' registros,
    elimina los más antiguos y deja solo los últimos 'dejar' mensajes.
    """
    
    # A falta de una idea mejor en tan poco tiempo,
    # esta función limpia la base para que no crezca indefinidamente,
    # pero siempre deja los últimos 5 mensajes de cada usuario para mantener contexto.
    
    mydb = get_db_connection()
    mycursor = mydb.cursor()
    mycursor.execute("SELECT DISTINCT telefono_wa FROM registro")
    telefonos = [row[0] for row in mycursor.fetchall()]
    for telefono in telefonos:
        mycursor.execute("SELECT COUNT(*) FROM registro WHERE telefono_wa=%s", (telefono,))
        total = mycursor.fetchone()[0]
        if total > umbral:
            mycursor.execute("""
                DELETE FROM registro
                WHERE telefono_wa = %s AND id NOT IN (
                    SELECT id FROM (
                        SELECT id FROM registro
                        WHERE telefono_wa = %s
                        ORDER BY id DESC
                        LIMIT %s
                    ) AS ultimos
                )
            """, (telefono, telefono, dejar))
            mydb.commit()
    mycursor.close()
    mydb.close()

def get_noticias_publicadas():
    """
    Consulta las últimas noticias publicadas desde la API.
    """
    url = f"{BASE_API_URL}/api/creus/api/cms/noticias/publicadas?page=1&per_page=5&sort_by=fecha_publicacion&sort_order=desc"
    try:
        r = requests.get(url, timeout=10)
        if r.ok:
            data = r.json().get("data", {})
            items = data.get("items", [])
            if not items:
                return "📰 No hay noticias publicadas en este momento."
            respuesta = "📰 *Últimas noticias publicadas:*\n\n"
            for n in items:
                titulo = n.get("titulo", "Sin título")
                fecha = n.get("fecha_publicacion", "")
                contenido = n.get("contenido", "")
                noticia_id = n.get("id", "")
                link = f"{CREUS_BASE_URL}noticia/{noticia_id}" if noticia_id else ""
                contenido_resumido = (contenido[:160] + "...") if len(contenido) > 160 else contenido
                respuesta += (
                    f"• *{titulo}* ({fecha})\n"
                    f"{contenido_resumido}\n"
                    f"🔗 {link}\n\n"
                )
            return respuesta[:4096]
        else:
            return "⚠️ No se pudo obtener la lista de noticias."
    except Exception as e:
        return f"❌ Error al consultar noticias: {str(e)}"


def get_horario():
    """
    Consulta los horarios de atención desde la API.
    """
    url = f"{BASE_API_URL}/api/creus/api/cms/horario/"
    try:
        r = requests.get(url, timeout=10)
        if r.ok:
            horarios = r.json()["data"]
            if not horarios or len(horarios) == 0:
                return "⏰ No hay horarios de atención disponibles en este momento."
            respuesta = "🕑 *Horarios de atención CREUS:*\n\n"
            for h in horarios:
                if h.get("visible", True):
                    dia = h.get("dia", "")
                    inicio = h.get("hora_inicio", "")
                    cierre = h.get("hora_cierre", "")
                    respuesta += f"• 📅 {dia}: de {inicio} a {cierre}\n"
            return respuesta
        else:
            return "⚠️ No se pudo obtener el horario de atención."
    except Exception as e:
        return f"❌ Error al consultar horario: {str(e)}"


def get_preguntas_frecuentes():
    """
    Consulta las preguntas frecuentes desde la API.
    """
    url = f"{BASE_API_URL}/api/creus/api/cms/preguntas-frecuentes/"
    try:
        r = requests.get(url, timeout=10)
        if r.ok:
            data = r.json().get("data", [])
            if not data:
                return "❓ No hay preguntas frecuentes disponibles en este momento."
            respuesta = "❓ *Preguntas frecuentes:*\n\n"
            for pf in data:
                pregunta = pf.get("pregunta", "Sin pregunta")
                respuesta_pf = pf.get("respuesta", "Sin respuesta")
                respuesta += f"• *{pregunta}*\n{respuesta_pf}\n\n"
                if len(respuesta) > 4000:
                    respuesta += "...\n(Límite de preguntas alcanzado)"
                    break
            return respuesta[:4096]
        else:
            return "⚠️ No se pudo obtener las preguntas frecuentes."
    except Exception as e:
        return f"❌ Error al consultar preguntas frecuentes: {str(e)}"


def get_contacto_info():
    """
    Consulta la información de contacto desde la API.
    """
    url = f"{BASE_API_URL}/api/creus/api/cms/contacto/"
    try:
        r = requests.get(url, timeout=10)
        if r.ok:
            contacto = r.json()["data"]
            respuesta = (
                "📞 *Datos de contacto CREUS*\n\n"
                f"🏫 Dirección: {contacto.get('direccion', '')}, {contacto.get('localidad', '')}, {contacto.get('provincia', '')}\n\n"
                f"📮 Código Postal: {contacto.get('codigo_postal', '')}\n\n"
                f"☎️ Teléfono: {contacto.get('telefono', '')}\n\n"
                f"💬 WhatsApp: {contacto.get('whatsapp', '')}\n\n"
                f"✉️ Email: {contacto.get('email', '')}\n\n"
                f"📸 Instagram: {contacto.get('instagram', '')}\n\n"
                f"📘 Facebook: {contacto.get('facebook', '')}\n\n"
            )
            return respuesta[:4096]
        else:
            return "⚠️ No se pudo obtener los datos de contacto."
    except Exception as e:
        return f"❌ Error al consultar datos de contacto: {str(e)}"


def get_propuestas_activas_con_inscripcion():
    """
    Consulta las carreras/propuestas activas con inscripción desde la API.
    """
    url = f"{BASE_API_URL}/api/creus/api/propuestas/activas-con-inscripciones"
    try:
        r = requests.get(url, timeout=10)
        if r.ok:
            propuestas = r.json()["data"]
            if not propuestas:
                return "📚 No hay carreras con inscripciones abiertas en este momento."
            respuesta = "🎓 *Carreras con inscripción abierta:*\n\n"
            for p in propuestas:
                nombre = p.get("nombre", "Sin nombre")
                tipo = p.get("tipo_propuesta", {}).get("nombre", "")
                if p.get("cohortes_disponibles"):
                    cohorte = p["cohortes_disponibles"][0]
                    fecha_inicio_cursado = cohorte.get("fecha_inicio_cursado", "")[:10]
                    fecha_inicio_preinsc = cohorte.get("fecha_inicio_preinscripcion", "")[:10]
                    fecha_cierre_preinsc = cohorte.get("fecha_cierre_preinscripcion", "")[:10]
                    fecha_fin_estimada = cohorte.get("fecha_estimada_finalizacion", "")[:10]
                    respuesta += (
                        f"✅ {nombre} ({tipo})\n"
                        f"• 🗓️ Inicio cursado: {fecha_inicio_cursado}\n"
                        f"• 📥 Inicio preinscripción: {fecha_inicio_preinsc}\n"
                        f"• ⏰ Cierre preinscripción: {fecha_cierre_preinsc}\n"
                        f"• 🎯 Fin estimada: {fecha_fin_estimada}\n\n"
                    )
                else:
                    respuesta += f"✅ {nombre} ({tipo})\n• Sin fechas de cohorte informadas\n\n"
            return respuesta[:4096]
        else:
            return "⚠️ No se pudo obtener la lista de carreras con inscripción abierta."
    except Exception as e:
        return f"❌ Error al consultar carreras: {str(e)}"


@app.route("/webhook/", methods=["POST", "GET"])
def webhook_whatsapp():
    """
    Endpoint para recibir y responder mensajes de WhatsApp.
    """
    try:
        if request.method == "GET":
            # Verificación del webhook con el token
            if request.args.get('hub.verify_token') == token_verificacion:
                return request.args.get('hub.challenge')
            else:
                return "Error de autentificacion."

        data = request.get_json()
        if 'messages' not in data['entry'][0]['changes'][0]['value']:
            return jsonify({"status": "no_message"}, 200)

        mensaje_info = data['entry'][0]['changes'][0]['value']['messages'][0]
        if 'text' not in mensaje_info:
            return jsonify({"status": "no_text"}, 200)

        telefonoCliente = mensaje_info['from']
        mensaje = mensaje_info['text']['body'].lower()
        idWA = mensaje_info['id']
        timestamp = mensaje_info['timestamp']

        import re

        if re.search(r'\b2\b', mensaje):
            respuesta = get_propuestas_activas_con_inscripcion()
        elif re.search(r'\b3\b', mensaje):
            respuesta = get_contacto_info()
        elif re.search(r'\b(hol+a+|hol[ai]+|buen[oa]s?|buenos días|buenas tardes|buenas noches|hey|hello|hi|qué tal|que tal|qué onda|que onda|como estas|como andas|saludos|que hay)\b', mensaje):
            respuesta = ("¡Hola! 👋🏻 Bienvenido/a al asistente virtual de CREUS.\n\n ¿En qué podemos ayudarte hoy? Estas son las opciones disponibles:\n\n" + MENU)
        elif re.search(r'\b1\b', mensaje):
            respuesta = get_horario()
        elif re.search(r'\b4\b', mensaje):
            respuesta = get_noticias_publicadas()
        elif re.search(r'\b5\b', mensaje):
            respuesta = get_preguntas_frecuentes()
        else:
            respuesta = (
                "No te entendí 🤔. Por favor, elegí una de las siguientes opciones:\n\n" +
                MENU
            )

        mydb = get_db_connection()
        mycursor = mydb.cursor()
        mycursor.execute("SELECT count(id) FROM registro WHERE id_wa=%s;", (idWA,))
        cantidad = mycursor.fetchone()[0]

        # Si el mensaje es nuevo, lo registra en la base de datos
        if cantidad == 0:
            sql = ("INSERT INTO registro "
                   "(mensaje_recibido, mensaje_enviado, id_wa, timestamp_wa, telefono_wa) "
                   "VALUES (%s, %s, %s, %s, %s);")
            valores = (mensaje, respuesta, idWA, timestamp, telefonoCliente)
            mycursor.execute(sql, valores)
            mydb.commit()
            limpiar_registros_usuarios()
            
        enviar(telefonoCliente, respuesta)
        return jsonify({"status": "success"}, 200)

    except Exception as e:
        # Guarda el error en un archivo de texto para debugging
        with open("texto.txt", "w") as f:
            f.write("ERROR: " + str(e))
        return jsonify({"status": "error", "message": str(e)}, 500)


def enviar(telefonoRecibe, respuesta):
    """
    Envía un mensaje a un teléfono específico usando WhatsApp API.
    """
    telefonoRecibe = telefonoRecibe.replace("549", "54")
    mensajeWa.send_message(respuesta, telefonoRecibe)


if __name__ == "__main__":
    app.run(debug=True, port=5005)
